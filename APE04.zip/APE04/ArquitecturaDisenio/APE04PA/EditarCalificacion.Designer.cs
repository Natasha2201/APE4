﻿namespace APE04PA
{
    partial class EditarCalificacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxNota4 = new System.Windows.Forms.TextBox();
            this.textBoxNota3 = new System.Windows.Forms.TextBox();
            this.textBoxNota2 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.labelAprueba = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.labelPromedio = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.buttonCalcularNota = new System.Windows.Forms.Button();
            this.buttonGuardarNotas = new System.Windows.Forms.Button();
            this.textBoxNota1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // textBoxNota4
            // 
            this.textBoxNota4.Location = new System.Drawing.Point(781, 85);
            this.textBoxNota4.Name = "textBoxNota4";
            this.textBoxNota4.Size = new System.Drawing.Size(100, 26);
            this.textBoxNota4.TabIndex = 66;
            // 
            // textBoxNota3
            // 
            this.textBoxNota3.Location = new System.Drawing.Point(566, 85);
            this.textBoxNota3.Name = "textBoxNota3";
            this.textBoxNota3.Size = new System.Drawing.Size(100, 26);
            this.textBoxNota3.TabIndex = 65;
            // 
            // textBoxNota2
            // 
            this.textBoxNota2.Location = new System.Drawing.Point(356, 88);
            this.textBoxNota2.Name = "textBoxNota2";
            this.textBoxNota2.Size = new System.Drawing.Size(100, 26);
            this.textBoxNota2.TabIndex = 64;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(707, 85);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 20);
            this.label14.TabIndex = 63;
            this.label14.Text = "Nota 4:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(485, 91);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 20);
            this.label13.TabIndex = 62;
            this.label13.Text = "Nota 3:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(276, 88);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 20);
            this.label11.TabIndex = 61;
            this.label11.Text = "Nota 2:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(53, 91);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 20);
            this.label10.TabIndex = 60;
            this.label10.Text = "Nota 1:";
            // 
            // labelAprueba
            // 
            this.labelAprueba.AutoSize = true;
            this.labelAprueba.Location = new System.Drawing.Point(394, 183);
            this.labelAprueba.Name = "labelAprueba";
            this.labelAprueba.Size = new System.Drawing.Size(25, 20);
            this.labelAprueba.TabIndex = 59;
            this.labelAprueba.Text = "....";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(177, 49);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(570, 20);
            this.label9.TabIndex = 58;
            this.label9.Text = "Notas superiores o iguales a 0 pero menor o igual a 10, los decimales con punto\r\n" +
    "";
            // 
            // labelPromedio
            // 
            this.labelPromedio.AutoSize = true;
            this.labelPromedio.Location = new System.Drawing.Point(394, 144);
            this.labelPromedio.Name = "labelPromedio";
            this.labelPromedio.Size = new System.Drawing.Size(21, 20);
            this.labelPromedio.TabIndex = 57;
            this.labelPromedio.Text = "...";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(276, 144);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(95, 20);
            this.label12.TabIndex = 56;
            this.label12.Text = "Respuesta: ";
            // 
            // buttonCalcularNota
            // 
            this.buttonCalcularNota.Location = new System.Drawing.Point(57, 129);
            this.buttonCalcularNota.Name = "buttonCalcularNota";
            this.buttonCalcularNota.Size = new System.Drawing.Size(136, 51);
            this.buttonCalcularNota.TabIndex = 55;
            this.buttonCalcularNota.Text = "Calcular:";
            this.buttonCalcularNota.UseVisualStyleBackColor = true;
            this.buttonCalcularNota.Click += new System.EventHandler(this.buttonCalcularNota_Click);
            // 
            // buttonGuardarNotas
            // 
            this.buttonGuardarNotas.Location = new System.Drawing.Point(356, 219);
            this.buttonGuardarNotas.Name = "buttonGuardarNotas";
            this.buttonGuardarNotas.Size = new System.Drawing.Size(140, 43);
            this.buttonGuardarNotas.TabIndex = 54;
            this.buttonGuardarNotas.Text = "GuardarNotas";
            this.buttonGuardarNotas.UseVisualStyleBackColor = true;
            this.buttonGuardarNotas.Click += new System.EventHandler(this.buttonGuardarNotas_Click);
            // 
            // textBoxNota1
            // 
            this.textBoxNota1.Location = new System.Drawing.Point(139, 85);
            this.textBoxNota1.Name = "textBoxNota1";
            this.textBoxNota1.Size = new System.Drawing.Size(100, 26);
            this.textBoxNota1.TabIndex = 53;
            // 
            // EditarCalificacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(917, 302);
            this.Controls.Add(this.textBoxNota4);
            this.Controls.Add(this.textBoxNota3);
            this.Controls.Add(this.textBoxNota2);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.labelAprueba);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.labelPromedio);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.buttonCalcularNota);
            this.Controls.Add(this.buttonGuardarNotas);
            this.Controls.Add(this.textBoxNota1);
            this.Name = "EditarCalificacion";
            this.Text = "EditarCalificacion";
            this.Load += new System.EventHandler(this.EditarCalificacion_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxNota4;
        private System.Windows.Forms.TextBox textBoxNota3;
        private System.Windows.Forms.TextBox textBoxNota2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label labelAprueba;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label labelPromedio;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button buttonCalcularNota;
        private System.Windows.Forms.Button buttonGuardarNotas;
        private System.Windows.Forms.TextBox textBoxNota1;
    }
}