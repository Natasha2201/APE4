﻿namespace APE04PA
{
    partial class AsignacionEstudiante
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.textBoxIdProfesor = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonCargarEstudintePorCedulaDeProfesor = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelAprueba = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.labelPromedio = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.buttonCalcularNota = new System.Windows.Forms.Button();
            this.buttonGuardarNotas = new System.Windows.Forms.Button();
            this.textBoxNota1 = new System.Windows.Forms.TextBox();
            this.labelTelefono = new System.Windows.Forms.Label();
            this.labelUsuario = new System.Windows.Forms.Label();
            this.labelApellido = new System.Windows.Forms.Label();
            this.labelCorreo = new System.Windows.Forms.Label();
            this.labelNombre = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labelCarrera = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBoxElegirEstudiante = new System.Windows.Forms.ComboBox();
            this.buttonVerEstudiantesConCalificaciones = new System.Windows.Forms.Button();
            this.labell = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBoxNota2 = new System.Windows.Forms.TextBox();
            this.textBoxNota3 = new System.Windows.Forms.TextBox();
            this.textBoxNota4 = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(149, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cedula del Docente";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(316, 54);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(104, 38);
            this.button1.TabIndex = 1;
            this.button1.Text = "Ver";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBoxIdProfesor
            // 
            this.textBoxIdProfesor.Location = new System.Drawing.Point(27, 54);
            this.textBoxIdProfesor.Name = "textBoxIdProfesor";
            this.textBoxIdProfesor.Size = new System.Drawing.Size(189, 26);
            this.textBoxIdProfesor.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(269, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(186, 20);
            this.label2.TabIndex = 3;
            this.label2.Text = "Ver Cedulas Disponibles:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Menu;
            this.panel1.Controls.Add(this.buttonCargarEstudintePorCedulaDeProfesor);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.textBoxIdProfesor);
            this.panel1.Location = new System.Drawing.Point(35, 32);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(483, 147);
            this.panel1.TabIndex = 4;
            // 
            // buttonCargarEstudintePorCedulaDeProfesor
            // 
            this.buttonCargarEstudintePorCedulaDeProfesor.Location = new System.Drawing.Point(12, 100);
            this.buttonCargarEstudintePorCedulaDeProfesor.Name = "buttonCargarEstudintePorCedulaDeProfesor";
            this.buttonCargarEstudintePorCedulaDeProfesor.Size = new System.Drawing.Size(238, 31);
            this.buttonCargarEstudintePorCedulaDeProfesor.TabIndex = 4;
            this.buttonCargarEstudintePorCedulaDeProfesor.Text = "Cargar Cedulas Estudintes";
            this.buttonCargarEstudintePorCedulaDeProfesor.UseVisualStyleBackColor = true;
            this.buttonCargarEstudintePorCedulaDeProfesor.Click += new System.EventHandler(this.buttonCargarEstudintePorCedulaDeProfesor_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.textBoxNota4);
            this.panel2.Controls.Add(this.textBoxNota3);
            this.panel2.Controls.Add(this.textBoxNota2);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.labelAprueba);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.labelPromedio);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.buttonCalcularNota);
            this.panel2.Controls.Add(this.buttonGuardarNotas);
            this.panel2.Controls.Add(this.textBoxNota1);
            this.panel2.Controls.Add(this.labelTelefono);
            this.panel2.Controls.Add(this.labelUsuario);
            this.panel2.Controls.Add(this.labelApellido);
            this.panel2.Controls.Add(this.labelCorreo);
            this.panel2.Controls.Add(this.labelNombre);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.labelCarrera);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.comboBoxElegirEstudiante);
            this.panel2.Location = new System.Drawing.Point(35, 206);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(938, 433);
            this.panel2.TabIndex = 5;
            // 
            // labelAprueba
            // 
            this.labelAprueba.AutoSize = true;
            this.labelAprueba.Location = new System.Drawing.Point(381, 340);
            this.labelAprueba.Name = "labelAprueba";
            this.labelAprueba.Size = new System.Drawing.Size(25, 20);
            this.labelAprueba.TabIndex = 32;
            this.labelAprueba.Text = "....";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(164, 206);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(570, 20);
            this.label9.TabIndex = 31;
            this.label9.Text = "Notas superiores o iguales a 0 pero menor o igual a 10, los decimales con punto\r\n" +
    "";
            // 
            // labelPromedio
            // 
            this.labelPromedio.AutoSize = true;
            this.labelPromedio.Location = new System.Drawing.Point(381, 301);
            this.labelPromedio.Name = "labelPromedio";
            this.labelPromedio.Size = new System.Drawing.Size(21, 20);
            this.labelPromedio.TabIndex = 30;
            this.labelPromedio.Text = "...";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(263, 301);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(95, 20);
            this.label12.TabIndex = 29;
            this.label12.Text = "Respuesta: ";
            // 
            // buttonCalcularNota
            // 
            this.buttonCalcularNota.Location = new System.Drawing.Point(44, 286);
            this.buttonCalcularNota.Name = "buttonCalcularNota";
            this.buttonCalcularNota.Size = new System.Drawing.Size(136, 51);
            this.buttonCalcularNota.TabIndex = 28;
            this.buttonCalcularNota.Text = "Calcular:";
            this.buttonCalcularNota.UseVisualStyleBackColor = true;
            this.buttonCalcularNota.Click += new System.EventHandler(this.buttonCalcularNota_Click);
            // 
            // buttonGuardarNotas
            // 
            this.buttonGuardarNotas.Location = new System.Drawing.Point(343, 376);
            this.buttonGuardarNotas.Name = "buttonGuardarNotas";
            this.buttonGuardarNotas.Size = new System.Drawing.Size(140, 43);
            this.buttonGuardarNotas.TabIndex = 27;
            this.buttonGuardarNotas.Text = "GuardarNotas";
            this.buttonGuardarNotas.UseVisualStyleBackColor = true;
            this.buttonGuardarNotas.Click += new System.EventHandler(this.buttonGuardarNotas_Click);
            // 
            // textBoxNota1
            // 
            this.textBoxNota1.Location = new System.Drawing.Point(126, 242);
            this.textBoxNota1.Name = "textBoxNota1";
            this.textBoxNota1.Size = new System.Drawing.Size(100, 26);
            this.textBoxNota1.TabIndex = 26;
            // 
            // labelTelefono
            // 
            this.labelTelefono.AutoSize = true;
            this.labelTelefono.Location = new System.Drawing.Point(549, 166);
            this.labelTelefono.Name = "labelTelefono";
            this.labelTelefono.Size = new System.Drawing.Size(59, 20);
            this.labelTelefono.TabIndex = 13;
            this.labelTelefono.Text = "----------";
            // 
            // labelUsuario
            // 
            this.labelUsuario.AutoSize = true;
            this.labelUsuario.Location = new System.Drawing.Point(799, 107);
            this.labelUsuario.Name = "labelUsuario";
            this.labelUsuario.Size = new System.Drawing.Size(59, 20);
            this.labelUsuario.TabIndex = 12;
            this.labelUsuario.Text = "----------";
            // 
            // labelApellido
            // 
            this.labelApellido.AutoSize = true;
            this.labelApellido.Location = new System.Drawing.Point(799, 53);
            this.labelApellido.Name = "labelApellido";
            this.labelApellido.Size = new System.Drawing.Size(59, 20);
            this.labelApellido.TabIndex = 11;
            this.labelApellido.Text = "----------";
            // 
            // labelCorreo
            // 
            this.labelCorreo.AutoSize = true;
            this.labelCorreo.Location = new System.Drawing.Point(549, 107);
            this.labelCorreo.Name = "labelCorreo";
            this.labelCorreo.Size = new System.Drawing.Size(59, 20);
            this.labelCorreo.TabIndex = 10;
            this.labelCorreo.Text = "----------";
            // 
            // labelNombre
            // 
            this.labelNombre.AutoSize = true;
            this.labelNombre.Location = new System.Drawing.Point(549, 53);
            this.labelNombre.Name = "labelNombre";
            this.labelNombre.Size = new System.Drawing.Size(59, 20);
            this.labelNombre.TabIndex = 9;
            this.labelNombre.Text = "----------";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(549, 134);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 20);
            this.label8.TabIndex = 8;
            this.label8.Text = "Telefono:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(799, 81);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 20);
            this.label7.TabIndex = 7;
            this.label7.Text = "Usuario:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(549, 81);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(144, 20);
            this.label6.TabIndex = 6;
            this.label6.Text = "Correo Electronico:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(799, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 20);
            this.label5.TabIndex = 5;
            this.label5.Text = "Apellido:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(549, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Nombre:";
            // 
            // labelCarrera
            // 
            this.labelCarrera.AutoSize = true;
            this.labelCarrera.Location = new System.Drawing.Point(23, 105);
            this.labelCarrera.Name = "labelCarrera";
            this.labelCarrera.Size = new System.Drawing.Size(45, 20);
            this.labelCarrera.TabIndex = 3;
            this.labelCarrera.Text = ".........";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(181, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Seleccionar Estudiante: ";
            // 
            // comboBoxElegirEstudiante
            // 
            this.comboBoxElegirEstudiante.FormattingEnabled = true;
            this.comboBoxElegirEstudiante.Location = new System.Drawing.Point(27, 55);
            this.comboBoxElegirEstudiante.Name = "comboBoxElegirEstudiante";
            this.comboBoxElegirEstudiante.Size = new System.Drawing.Size(223, 28);
            this.comboBoxElegirEstudiante.TabIndex = 0;
            this.comboBoxElegirEstudiante.SelectedIndexChanged += new System.EventHandler(this.comboBoxElegirEstudiante_SelectedIndexChanged);
            // 
            // buttonVerEstudiantesConCalificaciones
            // 
            this.buttonVerEstudiantesConCalificaciones.Location = new System.Drawing.Point(67, 56);
            this.buttonVerEstudiantesConCalificaciones.Name = "buttonVerEstudiantesConCalificaciones";
            this.buttonVerEstudiantesConCalificaciones.Size = new System.Drawing.Size(105, 36);
            this.buttonVerEstudiantesConCalificaciones.TabIndex = 6;
            this.buttonVerEstudiantesConCalificaciones.Text = "Ver";
            this.buttonVerEstudiantesConCalificaciones.UseVisualStyleBackColor = true;
            this.buttonVerEstudiantesConCalificaciones.Click += new System.EventHandler(this.buttonVerEstudiantesConCalificaciones_Click);
            // 
            // labell
            // 
            this.labell.AutoSize = true;
            this.labell.Location = new System.Drawing.Point(9, 21);
            this.labell.Name = "labell";
            this.labell.Size = new System.Drawing.Size(204, 20);
            this.labell.TabIndex = 7;
            this.labell.Text = "Ver Estudiantes Calificados";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.buttonVerEstudiantesConCalificaciones);
            this.panel3.Controls.Add(this.labell);
            this.panel3.Location = new System.Drawing.Point(556, 32);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(233, 147);
            this.panel3.TabIndex = 8;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::APE04PA.Properties.Resources.ButonRegresar;
            this.pictureBox1.Location = new System.Drawing.Point(825, 53);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(95, 95);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(40, 248);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(60, 20);
            this.label10.TabIndex = 33;
            this.label10.Text = "Nota 1:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(263, 245);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(60, 20);
            this.label11.TabIndex = 34;
            this.label11.Text = "Nota 2:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(472, 248);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 20);
            this.label13.TabIndex = 35;
            this.label13.Text = "Nota 3:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(694, 242);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 20);
            this.label14.TabIndex = 36;
            this.label14.Text = "Nota 4:";
            // 
            // textBoxNota2
            // 
            this.textBoxNota2.Location = new System.Drawing.Point(343, 245);
            this.textBoxNota2.Name = "textBoxNota2";
            this.textBoxNota2.Size = new System.Drawing.Size(100, 26);
            this.textBoxNota2.TabIndex = 37;
            // 
            // textBoxNota3
            // 
            this.textBoxNota3.Location = new System.Drawing.Point(553, 242);
            this.textBoxNota3.Name = "textBoxNota3";
            this.textBoxNota3.Size = new System.Drawing.Size(100, 26);
            this.textBoxNota3.TabIndex = 38;
            // 
            // textBoxNota4
            // 
            this.textBoxNota4.Location = new System.Drawing.Point(768, 242);
            this.textBoxNota4.Name = "textBoxNota4";
            this.textBoxNota4.Size = new System.Drawing.Size(100, 26);
            this.textBoxNota4.TabIndex = 39;
            // 
            // AsignacionEstudiante
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::APE04PA.Properties.Resources.imagenSoporte;
            this.ClientSize = new System.Drawing.Size(996, 659);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "AsignacionEstudiante";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AsignacionEstudiante";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBoxIdProfesor;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBoxElegirEstudiante;
        private System.Windows.Forms.Button buttonCargarEstudintePorCedulaDeProfesor;
        private System.Windows.Forms.Label labelCarrera;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelNombre;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label labelTelefono;
        private System.Windows.Forms.Label labelUsuario;
        private System.Windows.Forms.Label labelApellido;
        private System.Windows.Forms.Label labelCorreo;
        private System.Windows.Forms.Button buttonVerEstudiantesConCalificaciones;
        private System.Windows.Forms.Label labell;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label labelAprueba;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label labelPromedio;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button buttonCalcularNota;
        private System.Windows.Forms.Button buttonGuardarNotas;
        private System.Windows.Forms.TextBox textBoxNota1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxNota4;
        private System.Windows.Forms.TextBox textBoxNota3;
        private System.Windows.Forms.TextBox textBoxNota2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
    }
}